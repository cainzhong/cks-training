# Deprecated

**This Policy is deprecated**

Please use the FSGroup settings on the users policy to enforce FSGroup Settings.

[Users Policy](../users)
