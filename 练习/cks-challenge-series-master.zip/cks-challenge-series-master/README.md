# Kubernetes CKS Challenge Series

[CLICK HERE TO ACCESS CHALLENGES](https://killer.sh/r?d=cks-series)

This is the repo belonging to the challenges on Medium.

by [killer.sh](https://killer.sh)
